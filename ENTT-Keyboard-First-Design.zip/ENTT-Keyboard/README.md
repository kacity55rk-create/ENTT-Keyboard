# ENTT Keyboard 🇸🇩

Android IME starter project for Sudanese Arabic and English.

## Build
1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK, open ENTT Keyboard, enable it in system keyboard settings, then select it.

Package: `com.entt.keyboard`
Min Android: 6.0 (API 23)

This starter keyboard does not request Internet permission and does not transmit typed text.
