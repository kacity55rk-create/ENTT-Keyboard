package com.entt.keyboard

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class KeyboardService : InputMethodService() {
    private var arabic = true
    private var shifted = false
    private var symbols = false
    private var numberRow = true

    private val arabicRows = listOf("ضصثقفغعهخح", "شسيبلاتنمك", "ئءؤرلاىةوزظ")
    private val englishRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val symbolRows = listOf("1234567890", "@#\$%&-*+()", "!?/;:'\".,")
    private val numberKeys = "1234567890"

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shifted = info?.let {
            it.inputType and android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES != 0
        } ?: false
        refreshKeyboard()
    }

    private fun refreshKeyboard() {
        setInputView(buildKeyboard())
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(7), dp(5), dp(7))
            setBackgroundColor(BACKGROUND)
        }

        // Compact toolbar, similar to a modern mobile keyboard.
        val toolbar = row()
        toolbar.addView(key("☰", 0.85f, TOOL) { symbols = !symbols; refreshKeyboard() })
        toolbar.addView(key(if (arabic) "عربي" else "EN", 1.15f, ACCENT) {
            arabic = !arabic
            symbols = false
            refreshKeyboard()
        })
        toolbar.addView(key("😊", 0.9f, TOOL) { commit("😊") })
        toolbar.addView(key("⌫", 0.9f, DANGER) { deleteOne() })
        root.addView(toolbar)

        if (numberRow && !symbols) {
            val numbers = row()
            numberKeys.forEach { digit ->
                numbers.addView(key(digit.toString(), 1f, NUMBER_KEY) { commit(digit.toString()) })
            }
            root.addView(numbers)
        }

        val rows = when {
            symbols -> symbolRows
            arabic -> arabicRows
            else -> englishRows
        }

        rows.forEachIndexed { index, chars ->
            val line = row()
            // Slightly indent the middle and last letter rows for a familiar layout.
            if (index == 1) line.setPadding(dp(10), 0, dp(10), 0)
            if (index == 2) line.setPadding(dp(3), 0, dp(3), 0)

            chars.forEach { char ->
                val shown = if (!arabic && !symbols && shifted) char.uppercaseChar() else char
                line.addView(key(shown.toString(), 1f) { commit(shown.toString()) })
            }
            if (index == 2 && !symbols) {
                line.addView(key("⇧", 1.15f, ACCENT) {
                    shifted = !shifted
                    refreshKeyboard()
                })
            }
            root.addView(line)
        }

        val bottom = row()
        bottom.addView(key("?123", 1.15f, TOOL) {
            symbols = !symbols
            refreshKeyboard()
        })
        bottom.addView(key(if (arabic) "،" else ",", 0.8f) { commit(if (arabic) "،" else ",") })
        bottom.addView(key("🌐", 0.9f, TOOL) {
            arabic = !arabic
            symbols = false
            refreshKeyboard()
        })
        bottom.addView(key("مسافة", 3.2f, ACCENT) { commit(" ") })
        bottom.addView(key(".", 0.8f) { commit(".") })
        bottom.addView(key("↵", 1.05f, ACCENT) { enter() })
        root.addView(bottom)
        return root
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
    }

    private fun key(
        label: String,
        weight: Float,
        color: Int = KEY,
        action: () -> Unit
    ) = Button(this).apply {
        text = label
        textSize = when {
            label.length > 3 -> 12f
            label.length > 1 -> 14f
            else -> 18f
        }
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
        isAllCaps = false
        minHeight = dp(44)
        minimumHeight = dp(44)
        setPadding(0, 0, 0, 0)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        setOnClickListener { action() }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
        if (!symbols && shifted && !arabic) {
            shifted = false
            refreshKeyboard()
        }
    }

    private fun deleteOne() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val connection = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            connection.performEditorAction(action)
        } else {
            connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    companion object {
        private val BACKGROUND = Color.rgb(25, 34, 45)
        private val KEY = Color.rgb(58, 70, 85)
        private val NUMBER_KEY = Color.rgb(43, 55, 69)
        private val TOOL = Color.rgb(43, 58, 72)
        private val ACCENT = Color.rgb(16, 132, 116)
        private val DANGER = Color.rgb(151, 62, 62)
    }
}
