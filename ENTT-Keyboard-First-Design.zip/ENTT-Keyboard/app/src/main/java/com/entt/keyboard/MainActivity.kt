package com.entt.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 32)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }

        root.addView(TextView(this).apply {
            text = "ENTT Keyboard 🇸🇩"
            textSize = 29f
            setTextColor(0xFF14212B.toInt())
        })
        root.addView(TextView(this).apply {
            text = "لوحة مفاتيح عربية سودانية وإنجليزية\n\nتعمل لوحة ENTT دون اتصال بالإنترنت، ولا تجمع ما تكتبه."
            textSize = 17f
            setTextColor(0xFF34495E.toInt())
            setPadding(0, 22, 0, 28)
        })
        root.addView(Button(this).apply {
            text = "1. تفعيل لوحة ENTT"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. اختيار لوحة ENTT للكتابة"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        })
        root.addView(TextView(this).apply {
            text = "بعد التفعيل، افتح أي تطبيق للكتابة ثم اختر ENTT Keyboard من قائمة لوحات المفاتيح."
            textSize = 14f
            setTextColor(0xFF607080.toInt())
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
    }
}
